# RV LIFE: Simulator — Game Design Document
Version 1.0

## 1. High Concept
RV LIFE: Simulator is a browser-based, choice-driven football life simulator. The player creates a footballer and lives a career through matches, training, transfers, money, business, RV-Gram social media, relationships, marriage, children, family, and legacy.

The game deliberately avoids 3D/2D football controls. Match play is a text/RPG decision system inspired by football games: the player chooses dribble, pass, shoot, cross, press, tackle, etc., while an engine resolves the result from player attributes, form, stamina, morale, opponent strength, match pressure, tactics, and randomness.

## 2. Platforms
- Web browser
- Designed for desktop and mobile layouts
- Works as a static site
- Suitable for GitHub Pages
- No server is required for the core single-player save system

## 3. Save System
- 3 independent character slots
- Each slot contains its own world state
- Save/load/delete
- Avatar photo stored inside the save object
- Export save to JSON
- Import save from JSON
- Local browser persistence

## 4. Character Creation
Player can define:
- Name
- Age
- Country
- City
- Position
- Height
- Weight
- Preferred foot
- Background
- Personality

Player avatar photo is required.

## 5. Football Career
Attributes:
- Pace, acceleration, shooting, finishing, passing, vision, dribbling, ball control, crossing, heading, defending, physical, stamina
- Composure, decision making, positioning, leadership
- Overall, potential, form, morale, fitness, fatigue, injury, reputation

Career states:
- Amateur/Youth
- Professional
- Starter
- Star
- Superstar
- Legend
- Retirement

Systems:
- Training
- Matches
- Transfers
- Contracts
- Club reputation
- League progression
- Trophies
- Awards
- National team
- Retirement and legacy

## 6. Choice-Based Match Engine
Match situations appear as RPG choices. Example:
- Shoot
- Pass
- Dribble
- Cross
- Through ball
- Tackle
- Press
- Hold position

Resolution considers:
- Relevant player skill
- Current form
- Morale
- Fitness/stamina
- Opponent defense
- Goalkeeper
- pressure
- tactical style
- randomness

A match has events, score, minute, player performance, goals, assists, cards, injuries and rewards.

## 7. World Football
The game is designed for real-world football data, but the included starter dataset is intentionally a small fictional/placeholder dataset so the project can be used privately without embedding a commercial database.

The data layer is replaceable. Clubs, players, leagues and competitions can be expanded later without rewriting the engine.

## 8. Partner System
Partners are full character entities, not simple chat NPCs.

Six country pools:
- China
- South Korea
- England
- Japan
- Russia
- Turkey

Per country:
- 4 UR
- 6 SSS
- 10 SS
- 15 S
- 25 A
- 30 B
Total: 90 per country, 540 total.

Partner data:
- Name
- Age
- Birthday
- Country
- Occupation
- Personality
- Affection
- Trust
- Jealousy
- Compatibility
- Relationship status
- Story arc
- Events
- Inventory
- Frame collection
- Equipped frame
- Custom photo

Partner profile can be edited after acquisition:
- Name
- Age
- Birthday
- Country
- Occupation
- Photo

Changing profile identity does not erase relationship history.

## 9. Partner Rarity
B < A < S < SS < SSS < UR.

Rarity affects:
- Acquisition price
- Availability
- Starting stats
- Story depth
- Event complexity
- Cosmetic frame tier

Rarity does NOT automatically mean best compatibility.

## 10. Gacha / Acquisition
Country banners and a standard pool can be used.
The prototype uses in-game money for private single-player acquisition.
The system is designed to support pity counters later.

No real-money payment system is included.

## 11. Relationship
Stats:
- Affection
- Trust
- Jealousy
- Compatibility

Statuses:
- Acquaintance
- Friend
- Close Friend
- Dating
- Partner
- Engaged
- Married

Events:
- Date
- Gift
- Argument
- Jealousy
- Support
- Career conflict
- Breakup
- Special story event
- Anniversary
- Family event

There is no gameplay hard cap on number of partners. Technical storage is the only practical limitation.

## 12. Marriage and Children
Marriage is optional for having children.
A child can be created when affection/trust and a relationship event requirement are satisfied.

Child data:
- Name
- Birthday
- Age
- Gender
- Personality
- Education
- Parent relationship
- Interests
- Potential

Child stages:
- Baby
- Toddler
- Child
- Teen
- Young Adult

## 13. Family
Family systems include:
- Partner household
- Children
- Family events
- Parenting choices
- Education
- Family reputation
- Family wealth
- Family memories

## 14. Business Simulator
Business categories:
- Restaurant
- Clothing
- Technology
- Property
- Entertainment
- Sports
- Media
- Investment

Each business has:
- Capital
- Revenue
- Expenses
- Profit
- Reputation
- Risk
- Growth

Business runs passively as game time advances.

## 15. RV-Gram
Social platform:
- Feed
- Followers
- Likes
- Comments
- DM
- Trending
- News
- Transfer rumors
- Fan accounts
- Hate accounts
- Sponsors
- Viral moments

Social metrics react to football performance, personality, relationships, controversies and business.

## 16. Sponsor System
Sponsor contracts may have:
- Duration
- Payment
- Requirements
- Performance clauses
- Behavior clauses

Popularity and reputation influence offers.

## 17. News
Dynamic events produce:
- Transfer rumors
- Match headlines
- Viral posts
- Relationship news
- Injury news
- Sponsor news
- Fan reactions

## 18. Avatar Card and Frame System
Player avatar:
- Required uploaded photo
- Card-style profile
- Position
- OVR
- Name
- Nationality

Player frame tiers:
- OVR < 60: Light Brown/Bronze
- 60–69: Green
- 70–79: Silver
- 80–89: Gold
- 90–99: Legendary animated tiers

90+ can use animated effects such as:
- Cosmic
- Constellation
- Galaxy
- Dragon energy
- Celestial
- RV Sports
- Phenomenon
- Icon
- GOAT
- RV GOAT

Special event frames are independent from OVR and can be earned or purchased.

## 19. Partner Frame and Inventory
Partners have:
- Inventory
- Gifts
- Items
- Cosmetic frames
- Special frames
- Equipped frame

Partner frames can come from:
- Rarity
- Relationship milestones
- Events
- Achievements
- Purchases

## 20. Admin
Private/local admin mode exists for the two owner emails supplied by the project owner.

Important security rule:
A static GitHub Pages site cannot securely hide an admin email or authenticate a privileged user. Therefore the included admin gate is a local/private convenience feature, not a secure production authentication system. If the project is ever published publicly, admin authentication must be moved to a real backend/auth provider.

Admin abilities in the local prototype:
- Edit player money/stats
- Edit date
- Edit relationship values
- Add/remove money
- Add partner
- Modify partner profile
- Add child
- Add business
- Trigger news/event
- Inspect save state
- Reset slot

## 21. Technical Architecture
The supplied prototype is intentionally a single-page application:
- index.html
- CSS embedded
- JavaScript embedded

This makes it easy to upload directly to GitHub Pages.

Core state:
- gameState
- currentSlot
- player
- partners
- businesses
- children
- social
- news
- achievements
- world

Persistence:
- localStorage for save JSON
- uploaded avatar is stored as a data URL in the save for portability
- Export/Import is available

## 22. Design Rule
No system should exist in isolation.

Football affects:
- Money
- Social
- Sponsors
- Relationship
- Reputation

Social affects:
- Fans
- Sponsors
- Relationship
- News

Relationship affects:
- Morale
- Time
- Family
- Social

Business affects:
- Money
- Time
- Reputation

Family affects:
- Time
- Morale
- Legacy

Everything loops back into the player's life.

## 23. Prototype Scope
The included build is a genuinely playable vertical slice of the full architecture:
- 3 save slots
- Character creation
- Avatar upload
- OVR card/frame
- Choice-based football match engine
- Training
- Transfers
- Money
- RV-Gram
- Business
- Partner acquisition
- Partner customization
- Relationship events
- Marriage
- Children
- Family
- Inventory
- Frame collection
- Export/import
- Local admin

The data layer is intentionally expandable. It is not a claim to contain every real-world club/player or licensed person.
