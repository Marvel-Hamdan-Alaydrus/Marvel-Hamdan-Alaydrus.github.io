# RV LIFE: Simulator

This folder contains a playable single-page browser prototype based on the RV LIFE GDD.

## Run locally
Open `index.html` in a modern browser.

For best browser behavior, a local static server is recommended:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## GitHub Pages
Create a repository, upload `index.html` and the documentation, then enable GitHub Pages from the repository's Pages settings using the main branch/root folder.

## Included systems
- 3 independent save slots
- Character creation
- Required player photo upload
- OVR-based avatar frame
- Choice-based football matches
- Training
- Transfer market
- Money
- RV-Gram
- Partner gacha
- Six partner countries
- Partner rarity tiers
- Partner profile editing
- Partner photos
- Partner relationship stats
- Dating
- Marriage
- Children without mandatory marriage
- Child naming
- Business simulator
- Partner/player inventories
- Frame collection
- Export/import save
- Local admin convenience panel

## Important notes
The project is designed as a private single-player web game. It does not include real-money purchases.

The included football and partner data are deliberately fictional/placeholder data. The engine is designed so larger real-world datasets can be plugged in later.

The admin emails are included only as a local convenience gate. Because this is a static frontend, this is NOT secure authentication. Anyone with access to the source can inspect it. If the game is ever publicly deployed, move admin authentication and privileged operations to a backend/auth provider.

Uploaded photos are stored inside each browser save as data URLs. Very large photos will make saves larger. Resize photos before upload for smoother use.

## Suggested next production steps
1. Split the single HTML into modules when the project grows.
2. Replace placeholder football data with a properly licensed dataset.
3. Add a real backend if online accounts, cloud saves, secure admin, multiplayer, or live football data are needed.
4. Add richer match event chains, contracts, leagues, cups, national teams, sponsor contracts and generational family simulation.
